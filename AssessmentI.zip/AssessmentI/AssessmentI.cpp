// AssessmentI.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>
#include<fstream>
#include<string>
#include <deque>
#include <algorithm>

//using the namespace
using namespace std;
//declearing global variables
const int rows = 10;
const int cols = 2;
void searching();

string que;
int temp;


typedef deque<string> questionsContainer;

questionsContainer getQuestionsFromFile(string filename)
{
	questionsContainer questions;

	ifstream myfile(filename.c_str());

	string que;

	while (getline(myfile, que))
	{
		questions.push_back(que);

	}


	return questions;
}

void printQuestions(questionsContainer const& questions)
{

	for (auto const& questions : questions)
		cout << questions << '\n';
}



int main()
{


	//read from file
	string filename("questions.txt");

	questionsContainer questions = getQuestionsFromFile(filename);

	sort(questions.begin(), questions.end());


	printQuestions(questions);

	searching();

	string line;
	string array[10][2];

	ifstream ratesfile("q-a.txt");

	if (ratesfile.is_open())
	{
		cout << "\n";
		cout << "File Open\n";
		cout << "\n";
	}

	else
	{
		cout << "File not open\n";
	}

	for (int i = 0; i < 10; ++i)
	{
		for (int j = 0; j < 2; ++j)
		{

			if (getline(ratesfile, line, ';'))
			{
				array[i][j] = line;
				cout << array[i][j] << endl;
			}
		}
	}



	ratesfile.close();

	return 0;
}
void searching()
{
	ifstream fileInput;
	fileInput.open("questions.txt");
	string line, search;
	cout << "Please enter the term to search: ";
	cin >> search;
	for (unsigned int curLine = 0; getline(fileInput, line); curLine++)
	{
		if (line.find(search) != string::npos)
		{
			cout << "\n";
			cout << "***** Search for " << search <<" ***** "<< endl;
			cout << "found: " << search << " on line: " << curLine << endl;
			cout << line << endl;
			cout << "\n";
		}

	}
}